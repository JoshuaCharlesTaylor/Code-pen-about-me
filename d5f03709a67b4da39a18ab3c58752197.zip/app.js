var buttonPress = 1;
function blackOut() {
  document.body.style.backgroundColor = "black";
  document.getElementById("heading").style.color = "white";
  document.getElementById("heading").innerHTML = "Chapter 1: FOOL";
  document.getElementById("text").style.color = "white";
  document.getElementById("text").innerHTML = "You click that awful button. You are just like the rest of them. Such trigger happy fools. Leave now fool, and never come back!";
  document.getElementById("clicky").style.color = "white";
  document.getElementById("clicky").style.backgroundColor = "black";
}
